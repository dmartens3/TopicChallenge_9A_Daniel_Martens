This package uses HTMLParser to scrape the ip address listed on 
http://checkip.dyndns.org/ and it prints the ip address to console.